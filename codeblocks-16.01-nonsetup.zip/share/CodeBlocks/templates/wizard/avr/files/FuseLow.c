#include <avr/io.h>

FUSES = {
    LFUSE_DEFAULT
};
